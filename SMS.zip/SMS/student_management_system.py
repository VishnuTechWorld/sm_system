import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

# Database setup

def setup_database():
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            roll_number TEXT,
            name TEXT,
            degree TEXT,
            dob TEXT,
            city TEXT,
            department TEXT,
            phone TEXT,
            email TEXT,
            address TEXT,
            marks TEXT,
            attendance TEXT,
            fees TEXT,
            gender TEXT
        )
    """)
    conn.commit()
    conn.close()
def update_database():
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    try:
        cursor.execute("ALTER TABLE students ADD COLUMN roll_number TEXT")
        conn.commit()
    except sqlite3.OperationalError:
        # Column already exists
        pass
    conn.close()

# Run this once before starting your app
update_database()



# Add student to the database
import re  # For regular expression matching

# Add student to the database with phone number, DOB, email, and fees validation
def add_student():
    if not all([entry_roll_number.get(), entry_name.get(), entry_degree.get(), entry_dob.get()]):
        messagebox.showerror("Error", "Please fill in the required fields!")
        return

    # Validate phone number
    phone = entry_phone.get()
    if not phone.isdigit() or len(phone) != 10:
        messagebox.showerror("Error", "Phone number must be exactly 10 digits!")
        return

    # Validate DOB format
    dob = entry_dob.get()
    dob_pattern = r"^\d{2}/\d{2}/\d{4}$"  # Pattern for DD/MM/YYYY
    if not re.match(dob_pattern, dob):
        messagebox.showerror("Error", "DOB must be in DD/MM/YYYY format (e.g., 03/04/2004)!")
        return

    # Validate email
    email = entry_email.get()
    email_pattern = r"^[a-zA-Z0-9._%+-]+@gmail\.com$"  # Pattern for Gmail
    if not re.match(email_pattern, email):
        messagebox.showerror("Error", "Email must be a valid Gmail address (e.g., example@gmail.com)!")
        return

    # Validate fees field
    fees = entry_fees.get()
    if fees.lower() not in ['paid', 'unpaid']:
        messagebox.showerror("Error", "Fees must be either 'paid' or 'unpaid'!")
        return

    roll_number = entry_roll_number.get()

    # Check if roll number already exists
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM students WHERE roll_number = ?", (roll_number,))
    existing_roll_number = cursor.fetchone()
    conn.close()

    if existing_roll_number:
        messagebox.showwarning("Warning", "Roll number already exists!")
        return

    try:
        conn = sqlite3.connect("students.db")
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO students (roll_number, name, degree, dob, city, department, phone, email, address, marks, attendance, fees, gender)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            roll_number, entry_name.get(), entry_degree.get(), dob, entry_city.get(),
            entry_department.get(), phone, email,
            entry_address.get("1.0", tk.END).strip(), entry_marks.get(),
            entry_attendance.get(), fees, gender_var.get()
        ))
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "Student added successfully!")
        clear_form()
        view_records()
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")


# Update student profile
def update_student(student_id, new_data):
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE students
        SET name = ?, degree = ?, dob = ?, city = ?, department = ?, phone = ?, email = ?, address = ?, marks = ?, attendance = ?, fees = ?, gender = ?
        WHERE id = ?

    """, (*new_data, student_id))
    conn.commit()
    conn.close()
    messagebox.showinfo("Success", "Student profile updated successfully!")
    view_records()

# Delete student profile
def delete_student(student_id):
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM students WHERE id = ?", (student_id,))
    conn.commit()
    conn.close()
    messagebox.showinfo("Success", "Student profile deleted successfully!")
    view_records()

# Update the records frame
def view_records():
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("SELECT roll_number, name, degree FROM students")
    rows = cursor.fetchall()
    conn.close()

    # Clear existing rows
    for item in tree.get_children():
        tree.delete(item)

    # Insert new rows
    for row in rows:
        tree.insert("", tk.END, values=row)


#Student profile
def get_student_profile():
    def fetch_and_show():
        roll_number = entry_roll_number_input.get().strip()
        if not roll_number:
            messagebox.showerror("Error", "Please enter a roll number.")
            return
        
        conn = sqlite3.connect("students.db")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM students WHERE roll_number = ?", (roll_number,))
        student_data = cursor.fetchone()
        conn.close()
        
        if not student_data:
            messagebox.showerror("Error", "No student found with this roll number!")
            return
        
        # Show the student's profile in a new window
        profile_window = tk.Toplevel(root)
        profile_window.title(f"Profile: {roll_number}")
        
        # Set the size of the profile window
        window_width, window_height = 500, 500
        screen_width, screen_height = profile_window.winfo_screenwidth(), profile_window.winfo_screenheight()
        position_top = int(screen_height / 2 - window_height / 2)
        position_left = int(screen_width / 2 - window_width / 2)
        profile_window.geometry(f'{window_width}x{window_height}+{position_left}+{position_top}')
        
        labels = [
            ("Roll Number", student_data[1]),
            ("Name", student_data[2]),
            ("Degree", student_data[3]),
            ("Date of Birth", student_data[4]),
            ("City", student_data[5]),
            ("Department", student_data[6]),
            ("Phone", student_data[7]),
            ("Email", student_data[8]),
            ("Address", student_data[9]),
            ("Marks", student_data[10]),
            ("Fees", student_data[12]),
            ("Attendance", student_data[11]),
            

            
        ]
        
        for idx, (label, value) in enumerate(labels):
            tk.Label(profile_window, text=f"{label}: {value}", font=("Arial", 12)).pack(anchor="w", padx=10, pady=5)
        
        profile_window.mainloop()
    
    # Prompt the user for the roll number
    input_window = tk.Toplevel(root)
    input_window.title("Enter Roll Number")
    window_width, window_height = 300, 150
    screen_width, screen_height = input_window.winfo_screenwidth(), input_window.winfo_screenheight()
    position_top = int(screen_height / 2 - window_height / 2)
    position_left = int(screen_width / 2 - window_width / 2)
    input_window.geometry(f'{window_width}x{window_height}+{position_left}+{position_top}')
    
    tk.Label(input_window, text="Enter Roll Number:", font=("Arial", 12)).pack(pady=10)
    entry_roll_number_input = tk.Entry(input_window, font=("Arial", 12))
    entry_roll_number_input.pack(pady=10)
    
    tk.Button(input_window, text="Show Profile", command=fetch_and_show, bg="#2196F3", fg="white").pack(pady=10)

# Clear the form
def clear_form():
    entry_roll_number.delete(0, tk.END)
    entry_name.delete(0, tk.END)
    entry_degree.delete(0, tk.END)
    entry_dob.delete(0, tk.END)
    entry_city.delete(0, tk.END)
    entry_department.delete(0, tk.END)
    entry_phone.delete(0, tk.END)
    entry_email.delete(0, tk.END)
    entry_address.delete("1.0", tk.END)
    entry_marks.delete(0, tk.END)
    entry_attendance.delete(0, tk.END)
    entry_fees.delete(0, tk.END)
    gender_var.set("")

# Show student profile in a new window
def show_student_profile(student_id):
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students WHERE id = ?", (student_id,))
    student_data = cursor.fetchone()
    conn.close()

    if student_data:
        # Create a new profile window
        profile_window = tk.Toplevel(root)
        profile_window.title("Student Profile")
        profile_window.geometry("500x500")

        labels = [
            ("Roll Number", student_data[1]),
            ("Name", student_data[2]),
            ("Degree", student_data[3]),
            ("Date of Birth", student_data[4]),
            ("City", student_data[5]),
            ("Department", student_data[6]),
            ("Phone", student_data[7]),
            ("Email", student_data[8]),
            ("Address", student_data[9]),
            ("Marks", student_data[10]),
            ("Attendance", student_data[11]),
            ("Fees", student_data[12]),
            ("Gender", student_data[13])
        ]

        # Display student details in the profile window
        for idx, (label, value) in enumerate(labels):
            tk.Label(profile_window, text=f"{label}: {value}", font=("Arial", 12)).pack(anchor="w", padx=10, pady=5)


# Update the selected student by their roll number
def open_update_window():
    update_window = tk.Toplevel(root)
    update_window.title("Update Student Data")

    # Center the window on the screen
    window_width, window_height = 600, 600
    screen_width, screen_height = update_window.winfo_screenwidth(), update_window.winfo_screenheight()
    position_top = int(screen_height / 2 - window_height / 2)
    position_left = int(screen_width / 2 - window_width / 2)
    update_window.geometry(f'{window_width}x{window_height}+{position_left}+{position_top}')

    # Create a canvas and scrollbar
    canvas = tk.Canvas(update_window)
    scroll_y = tk.Scrollbar(update_window, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scroll_y.set)

    # Frame to hold the form fields
    form_frame = tk.Frame(canvas)
    canvas.create_window((0, 0), window=form_frame, anchor="nw")
    scroll_y.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)

    tk.Label(form_frame, text="Enter Roll Number", font=("Arial", 12)).grid(row=0, column=0, pady=10, padx=20)
    entry_roll_number_update = tk.Entry(form_frame, font=("Arial", 12))
    entry_roll_number_update.grid(row=0, column=1, pady=10, padx=20)

    def search_and_update():
        roll_number = entry_roll_number_update.get().strip()
        if not roll_number:
            messagebox.showerror("Error", "Please enter a roll number.")
            return

        # Fetch student data based on roll number
        conn = sqlite3.connect("students.db")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM students WHERE roll_number = ?", (roll_number,))
        student_data = cursor.fetchone()
        conn.close()

        if not student_data:
            messagebox.showerror("Error", "Student not found!")
            return

        # Clear previous content
        for widget in form_frame.winfo_children():
            widget.destroy()

        # Add form fields for updating data
        labels = [
            "Name", "Degree", "Date of Birth", "City", 
            "Department", "Phone", "Email", "Address", 
            "Marks", "Attendance", "Fees", "Gender"
        ]
        
        fields = {}
        tk.Label(form_frame, text=f"Roll Number: {student_data[1]}", font=("Arial", 12)).grid(row=0, column=0, columnspan=2, pady=10)

        for i, label in enumerate(labels):
            tk.Label(form_frame, text=label, font=("Arial", 12)).grid(row=i+1, column=0, pady=5, padx=20, sticky="w")
            entry = tk.Entry(form_frame, font=("Arial", 12))
            entry.insert(0, student_data[i+2])  # Skip ID and Roll Number
            entry.grid(row=i+1, column=1, pady=5, padx=20, sticky="w")
            fields[label] = entry

        def save_updates():
            updated_data = [entry.get().strip() for entry in fields.values()]
            updated_data.append(student_data[0])  # Append student ID for WHERE clause

            # Validate updated data
            if any(not value for value in updated_data[:-1]):  # Check for empty fields
                messagebox.showerror("Error", "All fields must be filled!")
                return

            # Update database
            try:
                conn = sqlite3.connect("students.db")
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE students
                    SET name = ?, degree = ?, dob = ?, city = ?, department = ?, phone = ?, email = ?, address = ?, marks = ?, attendance = ?, fees = ?, gender = ?
                    WHERE id = ?
                """, updated_data)
                conn.commit()
                conn.close()
                messagebox.showinfo("Success", "Student data updated successfully!")
                update_window.destroy()
                view_records()  # Refresh records view
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {e}")

        # Add Save button
        save_button = tk.Button(form_frame, text="Update", command=save_updates, bg="#4CAF50", fg="white")
        save_button.grid(row=len(labels)+1, column=0, columnspan=2, pady=20)

    # Add Search button
    search_button = tk.Button(form_frame, text="Search and Update", command=search_and_update, bg="#FFC107", fg="white")
    search_button.grid(row=0, column=2, pady=10, padx=20)



# GUI setup
root = tk.Tk()
root.title("Student Management System")
root.state("zoomed")  # Full-screen mode
root.configure(bg="#003366")

# Title
title_label = tk.Label(root, text="Student Management System", font=("Arial", 20, "bold"), bg="#003366", fg="white")
title_label.pack(pady=10)

# Left frame for student details
frame_details = tk.Frame(root, bg="#cce7ff")
frame_details.place(x=50, y=80, width=450, height=600)

# Add form fields
def create_form_field(frame, text, y):
    label = tk.Label(frame, text=text, font=("Arial", 12), bg="#cce7ff")
    label.place(x=10, y=y)
    entry = tk.Entry(frame, font=("Arial", 12), width=30)
    entry.place(x=150, y=y)
    return entry

entry_roll_number = create_form_field(frame_details, "Roll Number", 10)
entry_name = create_form_field(frame_details, "Name", 50)
entry_degree = create_form_field(frame_details, "Degree", 90)
entry_dob = create_form_field(frame_details, "Date of Birth", 130)
entry_city = create_form_field(frame_details, "City", 170)
entry_department = create_form_field(frame_details, "Department", 210)
entry_phone = create_form_field(frame_details, "Phone", 250)
entry_email = create_form_field(frame_details, "Email", 290)
entry_marks = create_form_field(frame_details, "Marks", 330)
entry_attendance = create_form_field(frame_details, "Attendance", 370)
entry_fees = create_form_field(frame_details, "Fees", 410)

# Address field
tk.Label(frame_details, text="Address", font=("Arial", 12), bg="#cce7ff").place(x=10, y=450)
entry_address = tk.Text(frame_details, font=("Arial", 12), width=30, height=3)
entry_address.place(x=150, y=450)

# Gender field
gender_var = tk.StringVar()
tk.Label(frame_details, text="Gender", font=("Arial", 12), bg="#cce7ff").place(x=10, y=530)
tk.Radiobutton(frame_details, text="Male", variable=gender_var, value="Male", bg="#cce7ff").place(x=150, y=530)
tk.Radiobutton(frame_details, text="Female", variable=gender_var, value="Female", bg="#cce7ff").place(x=220, y=530)
tk.Radiobutton(frame_details, text="Other", variable=gender_var, value="Other", bg="#cce7ff").place(x=300, y=530)

# Frame for buttons
button_frame = tk.Frame(frame_details, bg="#cce7ff")
button_frame.place(x=9, y=560, width=430, height=50)




def delete_selected_student():
    selected_item = tree.selection()  # Get selected row from treeview
    if selected_item:
        student_id = tree.item(selected_item)["values"][0]  # Extract the student ID from the selected row
        # Confirm before deleting
        if messagebox.askyesno("Confirm", "Are you sure you want to delete this student?"):
            delete_student(student_id)  # Call the delete_student function with the selected ID
        else:
            return
    else:
        messagebox.showwarning("No selection", "Please select a student to delete.")


# Add buttons to button_frame
tk.Button(button_frame, text="Add", 
          command=add_student, bg="#4CAF50", fg="white", width=8).place(x=10, y=10)
# Add the update button in the main window (right panel)
tk.Button(button_frame, text="Update", 
          command=open_update_window, bg="#FFC107", fg="white", width=8).place(x=100, y=10)
tk.Button(button_frame, text="Delete", bg="#D32F2F", fg="white", width=8, 
          command=delete_selected_student).place(x=190, y=10)
tk.Button(button_frame, text="Clear", bg="#D32F2F", fg="white", width=8, 
           command=clear_form).place(x=280, y=10)
tk.Button(button_frame, text="Profile", bg="#2196F3", fg="white", width=8, 
          command=get_student_profile).place(x=370, y=10)


# Right frame for records
frame_records = tk.Frame(root, bg="#e6f2ff")
frame_records.place(x=530, y=80, width=800, height=600)

# Treeview widget
columns = ("roll_number", "name", "degree")  # Removed "id"
tree = ttk.Treeview(frame_records, columns=columns, show="headings")

# Define headings
tree.heading("roll_number", text="Roll Number")
tree.heading("name", text="Name")
tree.heading("degree", text="Degree")

# Set column widths
tree.column("roll_number", width=150)
tree.column("name", width=200)
tree.column("degree", width=200)

tree.pack(fill="both", expand=True)

# Attach a scrollbar
scrollbar = ttk.Scrollbar(frame_records, orient="vertical", command=tree.yview)
tree.configure(yscrollcommand=scrollbar.set)
scrollbar.pack(side="right", fill="y")


setup_database()
view_records()

setup_database()
view_records()
root.mainloop()
